# 🏪 Store Sales and Profit Analysis

> **Internship Project Submission — Shadowfax**  
> Data Analysis using Python on the Sample Superstore Dataset

---

## 📌 Problem Statement

Analyzing the sales and profit performance of a retail store is a crucial task for businesses aiming to:
- Optimize operations
- Refine pricing strategies
- Enhance marketing efforts
- Improve inventory management

This project leverages data-driven insights to identify areas for improvement and drive revenue growth using **Python-based analysis** on the Sample Superstore dataset.

---

## 📁 Project Structure

```
store-sales-profit-analysis/
│
├── data/
│   └── Sample_Superstore.csv       # Raw dataset
│
├── outputs/
│   ├── fig1_overview_dashboard.png # KPIs, trend, category & sub-category charts
│   ├── fig2_regional_segment.png   # Regional & segment performance
│   └── fig3_timeseries_topbottom.png # Time series & top/bottom products
│
├── analysis.py                     # Main Python analysis script
├── requirements.txt                # Python dependencies
└── README.md                       # Project documentation
```

---

## 📊 Dataset Overview

| Property       | Detail                        |
|----------------|-------------------------------|
| Source         | Sample - Superstore           |
| Rows           | 9,994 orders                  |
| Columns        | 21 features                   |
| Date Range     | Jan 2014 – Dec 2017           |
| Categories     | Furniture, Office Supplies, Technology |
| Regions        | East, West, Central, South    |
| Segments       | Consumer, Corporate, Home Office |

---

## 🔍 Analysis Performed

### 1. Data Loading & Preprocessing
- Parsed `Order Date` and `Ship Date` as datetime
- Extracted `Year`, `Month`, `Month_Name` features
- Calculated `Profit_Margin = (Profit / Sales) × 100`

### 2. Exploratory Data Analysis (EDA)
- Shape, date range, null check
- Descriptive statistics for Sales, Profit, Discount, Quantity

### 3. Visualizations

#### 📌 Figure 1 — Overview Dashboard
- **KPI Cards**: Total Sales ($2.3M), Total Profit ($286K), Avg Margin (12%)
- **Monthly Trend**: Sales & Profit line chart across all years
- **Category Pie**: Share of sales per category
- **Sub-Category Bar**: Profit breakdown (loss-makers highlighted in red)

#### 📌 Figure 2 — Regional & Segment Analysis
- **Region Grouped Bar**: Sales vs Profit per region
- **Segment Donut**: Customer segment sales share
- **Margin Bar**: Average profit margin per region
- **Discount Scatter**: Relationship between discount rate and profit

#### 📌 Figure 3 — Time Series & Top/Bottom Analysis
- **Yearly Trend**: Category-wise sales growth from 2014–2017
- **Seasonality Heatmap**: Monthly sales pattern per year
- **Top 10 Products**: Most profitable products
- **Bottom 10 Products**: Loss-making products

---

## 💡 Key Insights

| Insight | Finding |
|--------|---------|
| 🏆 Best Region | **West** — Highest total profit |
| ⚠️ Worst Region | **Central** — Lowest profit |
| 📦 Best Category | **Technology** — Most profitable |
| 🟢 Best Sub-Category | **Copiers** |
| 🔴 Loss-Making Sub-Category | **Tables** (significant losses) |
| 👤 Top Customer Segment | **Consumer** — Highest sales volume |
| 💡 Discount Risk | Orders with >40% discount average **negative profit** |
| 📈 Peak Season | **Q4 (Oct–Dec)** is consistently the best quarter |

---

## 🚀 How to Run

### 1. Clone the Repository
```bash
git clone https://github.com/<your-username>/store-sales-profit-analysis.git
cd store-sales-profit-analysis
```

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Run the Analysis
```bash
python analysis.py
```

Charts will be saved to the `outputs/` folder automatically.

---

## 🛠 Technologies Used

- **Python 3.10+**
- **Pandas** — Data loading, cleaning, aggregation
- **NumPy** — Numerical operations
- **Matplotlib** — Custom visualizations & dashboards
- **Seaborn** — Heatmaps & statistical plots

---

## 📸 Sample Output

### Figure 1 — Overview Dashboard
![Overview Dashboard](outputs/fig1_overview_dashboard.png)

### Figure 2 — Regional & Segment Analysis
![Regional Analysis](outputs/fig2_regional_segment.png)

### Figure 3 — Time Series & Top/Bottom Products
![Time Series](outputs/fig3_timeseries_topbottom.png)

---

## 👤 Author

**[Your Full Name]**  
Internship Project | Shadowfax  
[Your Email] | [Your LinkedIn]

---

## 📄 License

This project is submitted as part of an internship assignment. Dataset sourced from public domain (Sample Superstore — Tableau).
